Download and unzip
